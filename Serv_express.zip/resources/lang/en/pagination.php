<?php

return [
    'previous'       => '&laquo; Previous',
    'next'           => 'Next &raquo;',

];
